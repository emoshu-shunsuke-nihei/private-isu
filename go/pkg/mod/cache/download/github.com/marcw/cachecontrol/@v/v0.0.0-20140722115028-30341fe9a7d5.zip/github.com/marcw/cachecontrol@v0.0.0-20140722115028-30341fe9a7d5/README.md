cachecontrol
============

Package cachecontrol provides HTTP Cache-Control header parsing with some utility functions to quickly deal with directives values
